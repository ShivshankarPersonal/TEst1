var mongoose = require("mongoose");
var express = require('express');
var bodyParser = require("body-parser");

var app = express();
var cors = require('cors');
app.use(cors());
app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({
//    extended: true
//}));
mongoose.connect("mongodb://localhost/jetbrains");
var Product = mongoose.model("Product", {name:String});


app.get('/', function(req, res){
    Product.find(function(err, products){
        res.send(products);
    })
});
//app.post('/add', function(req, res){
//    var newProd = req.body.name;
//    var product = new Product({name:newProd});
//    product.save(function(err){
//        res.send();
//        if(err){
//            console.log('failed');
//        }else {
//            console.log("saved")
//        }
//    });
//});
app.get('/add', function(req, res){
    //var newProd = req.body.name;
    var newProd = req.query.name;
    var product = new Product({name:newProd});
    product.save(function(err){
        res.send();
        if(err){
            console.log('failed');
        }else {
            console.log("saved")
        }
    });
});
app.listen(3000);






//var product = new Product({name:'Chrome'});

//product.save(function(error){
//    if(error){
//        console.log('failed');
//    }else {
//        console.log("saved");
//    }
//})

